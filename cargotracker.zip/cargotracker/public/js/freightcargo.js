//JS file 1

exports.getFreight=function (){
    //em.on( 'getFreight',function(){console.log("Event recieved")} )
    console.log("It is your freight cargo")

    return "freight"
}


