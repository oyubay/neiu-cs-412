exports.getFreight=function (){
    console.log("It is your freight cargo")
    return "freight"
}


